const mongoose = require('mongoose')


const studentSchema = new mongoose.Schema({
// A SCEHMA FOR THE DATABASE- STUDENT, MAJOR NAD THEIR COURSE
    name: {
        type: String,
        required: true
    },
    major: {
        type: String,
        required: true
    },
    course: {
        type: Boolean,
        required: true,
        default: false
    }

})

module.exports = mongoose.model('Student',studentSchema)