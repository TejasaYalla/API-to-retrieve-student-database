const express = require('express') // bringing in the express.js - framework
const mongoose = require('mongoose') // bringuin in the mongoose  - data modelling library
const url = 'mongodb://localhost/StudentDB' // a url for the database

const app = express()

mongoose.connect(url, {useNewUrlParser:true}) // TO AVOID WARNINGS - USE NEW URL PARSER
const con = mongoose.connection // FOR THE CONNECTION HANDLE
// TO LET THE DATA BASE KNOW THAT WE ARE CONNECTED 
con.on('open', () => {
    console.log('Connection Established!!!')
})

app.use(express.json())

const studentRouter = require('./routes/students') // FOR ALL THE STUDENT REQUESTS WE SEND THE REQUEST TO STUDENT ROUTES
app.use('/students',studentRouter)
// TO LISTEN TO THE SERVER- AS IN SEE WHEN WE GET THE REQUESTS
app.listen(9000, () => {
    console.log('Server started')
})
// FOR DIFFERENT URLS WE HAVE DIFFERENT REQUESTS, SO FOR THAT WE CREATE ROUTES